// === HÀM GIẢ LẬP CLICK NHƯ NGƯỜI THẬT ===
function simulateMouseClick(element) {
    try { element.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    const events = ['mouseover', 'mousedown', 'mouseup', 'click'];
    events.forEach(eventType => {
        const event = new MouseEvent(eventType, { bubbles: true, cancelable: true, view: window, buttons: 1 });
        element.dispatchEvent(event);
    });
    try { element.click(); } catch(e){}
}

let timerId = null;
let scrollIntervalId = null;
let adCheckIntervalId = null; 
let isNavigating = false; 
let isProcessingAds = false;

// Danh sách link
const FIXED_LINKS = [
    "https://9xcongit.com/category/tech/",
	"https://9xcongit.com/category/business/",
	"https://9xcongit.com/category/game-app/",
	"https://9xcongit.com/category/mmo/",
	"https://9xcongit.com/category/tips-leaks/",
    "https://9xcongit.com/how-to-get-a-free-vps-with-root-access-8vcpu/",
	"https://9xcongit.com/free-vps-24-7-uptime-tutorial/",
	"https://9xcongit.com/how-to-get-a-free-vps-with-quiklab/",
	"https://9xcongit.com/how-to-create-free-46-vcpu-vps-with-root-access/",
	"https://9xcongit.com/how-to-try-nvidia-gpu-free/",
    "https://9xcongit.com/how-to-check-gmail-creation-date-using-google-takeout/",
    "https://9xcongit.com/free-vps-keep-dying-how-to-maintain-100-uptime-until-the-end-of-2026/",
    "https://9xcongit.com/how-to-create-a-free-gmail-address-in-the-us/",
    "https://9xcongit.com/free-cloudsigma-trial-7-day-instant-demo/",
    "https://9xcongit.com/create-free-vps-play-with-docker/",
    "https://9xcongit.com/what-is-tiktok-how-to-make-money-from-tiktok/",
    "https://9xcongit.com/what-is-socks5/",
    "https://9xcongit.com/how-to-get-free-vps-no-credit-card/",
    "https://9xcongit.com/what-is-docker/",
    "https://9xcongit.com/what-is-ssl/",
    "https://9xcongit.com/future/",
    "https://9xcongit.com/stock/",
    "https://9xcongit.com/1-usd/",
    "https://9xcongit.com/1-btc/",
    "https://9xcongit.com/how-to-open-a-successful-coffee-shop/",
    "https://9xcongit.com/steps-to-create-a-new-brand-and-start-selling/",
    "https://9xcongit.com/increase-sales-with-repetitive-marketing-methods/",
    "https://9xcongit.com/the-crowd-effect-in-sales/",
    "https://9xcongit.com/increase-traffic-with-social-media-sharing-features/",
    "https://9xcongit.com/making-money-online-mmo-massive-online-opportunity/",
    "https://9xcongit.com/bitcoin/"
];

function goToNextPage() {
    if (isProcessingAds) return;
    if (isNavigating) return;
    isNavigating = true;

    stopScrolling();
    stopAdScanner(); 
    clearNavigationTimer();

    chrome.storage.local.get(['currentLinkIndex'], (result) => {
        let currentIndex = result.currentLinkIndex || 0;
        if (currentIndex >= FIXED_LINKS.length) currentIndex = 0;
        const nextUrl = FIXED_LINKS[currentIndex];
        console.log("Auto Browser: Chuyển hướng tới -> " + nextUrl);
        
        const nextIndex = (currentIndex + 1) % FIXED_LINKS.length;
        chrome.storage.local.set({ currentLinkIndex: nextIndex }, () => {
            window.location.href = nextUrl;
        });
    });
}

function clearNavigationTimer() {
    if (timerId) { clearTimeout(timerId); timerId = null; }
}

function startNavigationTimer(waitTime = 60000) {
    clearNavigationTimer();
    timerId = setTimeout(() => { goToNextPage(); }, waitTime); 
}

// ----------------- QUÉT MỌI CHỖ TRÊN TRANG ĐỂ TÌM AD TEXT -----------------
function processNextAd() {
    if (isNavigating) return; 

    let unclickedAds = [];
    const targetKeywords = ['game', 'android', 'mobile app', 'business', 'iphone', 'service', 'computer', 'software', 'vps'];

    // Quét toàn bộ các thẻ A và SPAN trên trang (không quan tâm nó bọc ở đâu)
    document.querySelectorAll('a, span').forEach(el => {
        // Bỏ qua nếu đã click rồi
        if (el.dataset.autoClicked === "true") return;

        let isAdText = false;
        const className = (el.className || '').toLowerCase();
        const text = (el.innerText || '').toLowerCase();
        
        // 1. Nhận diện chuẩn xác bằng Class hoặc Attribute của Google
        if (
            className.includes('google-anno') || 
            className.includes('intent') || 
            el.hasAttribute('data-ad-intent') || 
            el.hasAttribute('data-google-query-id') ||
            (el.tagName === 'A' && el.href && el.href.includes('google.com/ads/'))
        ) {
            isAdText = true;
        }

        // 2. Nhận diện dựa vào Text (từ khóa) nếu Google cố tình ẩn class
        if (!isAdText && targetKeywords.some(kw => text.includes(kw))) {
            // Xác nhận nó là một cái link có thể click được (Tránh click nhầm chữ trong bài)
            if (el.tagName === 'A') {
                const href = el.getAttribute('href');
                // Link Ad Intent thường ko có href trỏ đi trang khác, hoặc href="#"
                if (!href || href === '#' || href.includes('javascript:')) {
                    isAdText = true;
                }
            } else if (el.style.cursor === 'pointer' || className.includes('link')) {
                isAdText = true;
            }
        }

        // Nếu xác nhận là Quảng cáo Text, kiểm tra xem có đang hiển thị không
        if (isAdText) {
            const rect = el.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                // Đảm bảo không thêm trùng
                if (!unclickedAds.some(ad => ad.element === el)) {
                    unclickedAds.push({ element: el, topPos: rect.top });
                }
            }
        }
    });

    // Sắp xếp ưu tiên click từ trên xuống dưới
    unclickedAds.sort((a, b) => a.topPos - b.topPos);

    if (unclickedAds.length > 0) {
        isProcessingAds = true;
        stopScrolling(); 
        clearNavigationTimer(); // Tạm dừng chuyển trang để click hết

        const targetAd = unclickedAds[0].element;
        console.log("Auto Browser: Bắt được Text Quảng Cáo ->", targetAd.innerText || "Google Text Ad");
        
        try {
            targetAd.dataset.autoClicked = "true"; 
            simulateMouseClick(targetAd);
            console.log("Auto Browser: Đã Click! Tạm dừng 5 giây để xem...");
            
            // Chờ 5 giây rồi tắt popup
            setTimeout(closeAdAndProcessNext, 5000);
        } catch (error) {
            closeAdAndProcessNext(); 
        }
    } else {
        if (isProcessingAds) {
            console.log("Auto Browser: Đã click sạch sành sanh các text quảng cáo trên màn hình. Lướt web tiếp...");
            isProcessingAds = false;
            startScrolling();
            startNavigationTimer(20000); // Lướt thêm 20 giây rồi chuyển trang
        }
    }
}

function closeAdAndProcessNext() {
    console.log("Auto Browser: Hoàn thành 5 giây. Nhấn ESC đóng hộp thoại...");
    
    // Bắn lệnh ESC mạnh mẽ
    const escEvent = new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true });
    document.dispatchEvent(escEvent);
    document.body.dispatchEvent(escEvent);
    window.dispatchEvent(escEvent);

    // Tìm và nhấn các nút Đóng chéo (nếu ESC không ăn thua)
    const closeSelectors = ['[aria-label*="Close"]', '[aria-label*="Đóng"]', '[aria-label*="Đóng quảng cáo"]', '.close-button', '.btn-close', '#dismiss-button', 'div[role="button"][tabindex="0"]'].join(', ');
    document.querySelectorAll(closeSelectors).forEach(btn => { try { btn.click(); } catch (e) {} });

    // Mở khóa cuộn trang
    document.body.style.overflow = ''; document.documentElement.style.overflow = '';

    // Đợi hộp thoại tắt hẳn rồi vòng lại đi săn Text Ad tiếp theo
    setTimeout(() => {
        processNextAd();
    }, 1500);
}

function startAdScanner() {
    adCheckIntervalId = setInterval(() => {
        if (!isProcessingAds && !isNavigating) processNextAd();
    }, 3000);
}

function stopAdScanner() {
    if (adCheckIntervalId) { clearInterval(adCheckIntervalId); adCheckIntervalId = null; }
}

function startScrolling() {
    stopScrolling();
    scrollIntervalId = setInterval(() => {
        const isAtBottom = (window.innerHeight + Math.ceil(window.scrollY)) >= document.body.offsetHeight - 5;
        if (!isAtBottom) {
            window.scrollBy(0, 2); 
        } else if (!isProcessingAds) {
            goToNextPage(); 
        }
    }, 30);
}

function stopScrolling() {
    if (scrollIntervalId) { clearInterval(scrollIntervalId); scrollIntervalId = null; }
}

function startAutoBrowse() {
    // Nếu dính quảng cáo Vignette che cả màn hình thì chuyển về trang chủ xử lý
    if (window.location.href.includes('google_vignette')) {
        window.location.href = 'https://9xcongit.com/'; return; 
    }
    
    isProcessingAds = false; 
    isNavigating = false;
    
    startScrolling();
    startAdScanner(); 
    startNavigationTimer(60000); // Đếm ngược 1 phút cho bài viết này
}

function stopAutoBrowse() {
    clearNavigationTimer(); 
    stopScrolling(); 
    stopAdScanner(); 
    isNavigating = false; 
    isProcessingAds = false;
}

chrome.storage.local.get(['autoBrowseActive'], (result) => { 
    if (result.autoBrowseActive) setTimeout(startAutoBrowse, 2000); 
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.autoBrowseActive) {
        if (changes.autoBrowseActive.newValue) startAutoBrowse();
        else stopAutoBrowse();
    }
});