let timerId = null;
let scrollIntervalId = null;
let adCheckIntervalId = null; // Variable to store the ad scanning interval ID
let isNavigating = false; // Flag to prevent triggering page navigation twice
let isViewingAd = false; // Flag to check if currently stopped to view an ad

// Unlimited list of links. Add as many as you like.
const FIXED_LINKS = [
    "https://9xcongit.com/how-to-get-a-free-vps-with-root-access-8vcpu/",
	"https://9xcongit.com/free-vps-24-7-uptime-tutorial/",
	"https://9xcongit.com/how-to-get-a-free-vps-with-quiklab/",
	"https://9xcongit.com/how-to-create-free-46-vcpu-vps-with-root-access/",
	"https://9xcongit.com/how-to-try-nvidia-gpu-free/",
    "https://9xcongit.com/how-to-check-gmail-creation-date-using-google-takeout/",
    "https://9xcongit.com/free-vps-keep-dying-how-to-maintain-100-uptime-until-the-end-of-2026/",
    "https://9xcongit.com/how-to-create-a-free-gmail-address-in-the-us/",
    "https://9xcongit.com/free-cloudsigma-trial-7-day-instant-demo/",
    "https://9xcongit.com/create-free-vps-play-with-docker/",
    "https://9xcongit.com/what-is-tiktok-how-to-make-money-from-tiktok/",
    "https://9xcongit.com/what-is-socks5/",
    "https://9xcongit.com/how-to-get-free-vps-no-credit-card/",
    "https://9xcongit.com/what-is-docker/",
    "https://9xcongit.com/what-is-ssl/",
    "https://9xcongit.com/future/",
    "https://9xcongit.com/stock/",
    "https://9xcongit.com/1-usd/",
    "https://9xcongit.com/1-btc/",
    "https://9xcongit.com/how-to-open-a-successful-coffee-shop/",
    "https://9xcongit.com/steps-to-create-a-new-brand-and-start-selling/",
    "https://9xcongit.com/when-do-you-need-to-promote-your-business/",
    "https://9xcongit.com/increase-sales-with-repetitive-marketing-methods/",
    "https://9xcongit.com/the-crowd-effect-in-sales/",
    "https://9xcongit.com/increase-traffic-with-social-media-sharing-features/",
    "https://9xcongit.com/making-money-online-mmo-massive-online-opportunity/",
    "https://9xcongit.com/the-best-side-jobs-to-boost-your-income-from-home/",
    "https://9xcongit.com/stay-ahead-of-your-competitors-with-a-professional-seo-company/",
    "https://9xcongit.com/what-major-should-you-choose-to-create-million-view-content/",
	"https://9xcongit.com/how-to-play-gta-vice-city-online-no-download/",
    "https://9xcongit.com/bitcoin/"
];

// Function to handle navigating to the next link in order
function goToNextPage() {
    // If currently viewing an ad (10 seconds) but web browsing time is up,
    // "extend" the time by 10 seconds before navigating to finish viewing the ad.
    if (isViewingAd) {
        timerId = setTimeout(goToNextPage, 10000);
        return;
    }

    if (isNavigating) return;
    isNavigating = true;

    stopScrolling();
    stopAdScanner(); // Stop scanning for ads when preparing to navigate
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }

    chrome.storage.local.get(['currentLinkIndex'], (result) => {
        let currentIndex = result.currentLinkIndex || 0;

        if (currentIndex >= FIXED_LINKS.length) {
            currentIndex = 0;
        }

        const nextUrl = FIXED_LINKS[currentIndex];
        console.log("Auto Browser: Redirecting to -> " + nextUrl);

        const nextIndex = (currentIndex + 1) % FIXED_LINKS.length;

        chrome.storage.local.set({ currentLinkIndex: nextIndex }, () => {
            window.location.href = nextUrl;
        });
    });
}

// ----------------- FIND AND CLICK AD INTENT TEXTS -----------------
function scanAndClickHiddenAds() {
    // If paused for 10s to view an ad, do not scan for more
    if (isViewingAd) return; 

    // Classes and attributes commonly used by Google AdSense for Ad Intents
    const intentSelectors = [
        'a[class*="google-anno"]', 
        'a[class*="intent"]', 
        '[class*="google-intent"]',
        'a[data-ad-intent]',
        'a[data-google-query-id]', 
        'span[class*="google-anno"]'
    ].join(', ');

    // Find all intent elements on the page
    const rawElements = document.querySelectorAll(intentSelectors);
    
    let normalAds = [];
    let floatingAds = [];

    for (let i = 0; i < rawElements.length; i++) {
        const el = rawElements[i];

        // Skip if already clicked
        if (el.dataset.autoClicked === "true") continue;
        
        // Skip absolutely if inside a standard banner ad
        if (el.closest('ins.adsbygoogle') || el.closest('iframe')) continue;

        // Get coordinates to sort top-to-bottom and check visibility
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;

        // Check if the element is part of a sticky/floating popup (e.g., bottom right corner)
        let isFloating = false;
        let currentEl = el;
        
        // Traverse up the DOM tree to see if it or any parent is position: fixed or sticky
        while (currentEl && currentEl !== document.body) {
            const style = window.getComputedStyle(currentEl);
            if (style.position === 'fixed' || style.position === 'sticky') {
                isFloating = true;
                break;
            }
            currentEl = currentEl.parentElement;
        }

        if (isFloating) {
            floatingAds.push({ element: el, topPos: rect.top });
        } else {
            normalAds.push({ element: el, topPos: rect.top });
        }
    }

    // Sort both arrays from top to bottom (Y coordinate)
    normalAds.sort((a, b) => a.topPos - b.topPos);
    floatingAds.sort((a, b) => a.topPos - b.topPos);

    // Combine them: Prioritize normal inline ads first, then floating popup ads
    const sortedAds = [...normalAds, ...floatingAds];

    if (sortedAds.length > 0) {
        const targetAd = sortedAds[0].element;
        
        console.log("Auto Browser: Detected Google Intent Text ->", targetAd.innerText || "Hidden text");
        
        try {
            // Click the text
            targetAd.click(); 
            targetAd.dataset.autoClicked = "true"; // Mark as clicked
            isViewingAd = true; // Set viewing flag
            
            console.log("Auto Browser: Clicked! Pausing scroll for 10 seconds to view ad...");
            stopScrolling(); // Stop scrolling
            
            // Wait exactly 10 seconds, then close popup and resume
            setTimeout(() => {
                closeAdAndResume();
            }, 10000);

        } catch (error) {
            console.error("Auto Browser: Error clicking text", error);
        }
    }
}

// Function to close ad popup and resume browsing
function closeAdAndResume() {
    console.log("Auto Browser: 10 seconds completed. Closing ad popup and resuming...");
    
    // 1. Send "ESC" key event
    const escEvent = new KeyboardEvent('keydown', {
        key: 'Escape', code: 'Escape', keyCode: 27, which: 27, 
        bubbles: true, cancelable: true, composed: true
    });
    document.dispatchEvent(escEvent);
    document.body.dispatchEvent(escEvent);

    // 2. Try to find and click "Close" buttons
    const closeSelectors = [
        '[aria-label*="Close"]', '[aria-label*="Đóng"]', '[aria-label*="Đóng quảng cáo"]',
        '.close-button', '.btn-close', '#dismiss-button', '[id*="dismiss"]'
    ].join(', ');
    
    const closeButtons = document.querySelectorAll(closeSelectors);
    closeButtons.forEach(btn => {
        try { btn.click(); } catch (e) {}
    });

    // 3. STRONG MEASURE: Find full-screen Overlays (Google ad overlays) and hide them
    try {
        const allOverlays = document.querySelectorAll('ins.adsbygoogle, iframe, div');
        allOverlays.forEach(el => {
            const style = window.getComputedStyle(el);
            // Trigger if it's fixed/absolute and has high z-index
            if ((style.position === 'fixed' || style.position === 'absolute') && parseInt(style.zIndex, 10) > 1000) {
                const rect = el.getBoundingClientRect();
                // Confirm it takes up a large portion of the screen
                if (rect.width > window.innerWidth * 0.4 && rect.height > window.innerHeight * 0.4) {
                    console.log("Auto Browser: Used strong measure - Hiding ad overlay.");
                    el.style.display = 'none';
                    el.style.opacity = '0';
                    el.style.pointerEvents = 'none';
                }
            }
        });

        // Unlock scrollbar (Sometimes Google locks scroll with overflow: hidden)
        document.body.style.overflow = 'auto';
        document.documentElement.style.overflow = 'auto';
    } catch (err) {
        console.error("Auto Browser: Error while hiding Overlay", err);
    }

    // Wait 1 second for popup closing animation to finish, then scroll
    setTimeout(() => {
        isViewingAd = false;
        // Check to ensure it's not time to navigate yet before scrolling
        if (!isNavigating) {
            startScrolling();
        }
    }, 1000);
}

function startAdScanner() {
    // Scan the page every 3 seconds to see if Google rendered intent text
    adCheckIntervalId = setInterval(() => {
        scanAndClickHiddenAds();
    }, 3000);
}

function stopAdScanner() {
    if (adCheckIntervalId) {
        clearInterval(adCheckIntervalId);
        adCheckIntervalId = null;
    }
}
// ----------------------------------------------------------------------

function startScrolling() {
    const SCROLL_SPEED = 30;

    // Ensure no duplicate scrolling intervals
    stopScrolling();

    scrollIntervalId = setInterval(() => {
        const isAtBottom = (window.innerHeight + Math.ceil(window.scrollY)) >= document.body.offsetHeight - 5;
        
        if (!isAtBottom) {
            window.scrollBy(0, 2); 
        } else {
            console.log("Auto Browser: Reached bottom of page, skipping wait time and navigating to new link!");
            goToNextPage(); 
        }
    }, SCROLL_SPEED);
}

function stopScrolling() {
    if (scrollIntervalId) {
        clearInterval(scrollIntervalId);
        scrollIntervalId = null;
    }
}

function startAutoBrowse() {
    // 1. CHECK FULL SCREEN AD (VIGNETTE)
    if (window.location.href.includes('google_vignette')) {
        console.log("Auto Browser: Stuck on ad page, automatically redirecting to homepage...");
        window.location.href = 'https://9xcongit.com/';
        return; 
    }

    // Fixed waiting time: 1 minute (60,000 milliseconds)
    const waitTime = 60000; 

    console.log(`Auto Browser: Maximum time on this page is ${Math.round(waitTime/1000)} seconds...`);

    // Start processes
    startScrolling();
    startAdScanner(); // Start intent text scanner

    // Set navigation timer
    timerId = setTimeout(() => {
        console.log("Auto Browser: Browsing time is up, proceeding to navigate link...");
        goToNextPage();
    }, waitTime); 
}

function stopAutoBrowse() {
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }
    stopScrolling();
    stopAdScanner(); // Stop scanner
    isNavigating = false;
    isViewingAd = false;
    console.log("Auto Browser: Stopped.");
}

// Initialize state when page fully loads
chrome.storage.local.get(['autoBrowseActive'], (result) => {
    if (result.autoBrowseActive) {
        startAutoBrowse();
    }
});

// Listen for toggle changes from the Popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (changes.autoBrowseActive) {
        if (changes.autoBrowseActive.newValue) {
            startAutoBrowse();
        } else {
            stopAutoBrowse();
        }
    }
});