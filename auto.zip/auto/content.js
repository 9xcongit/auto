let timerId = null;
let scrollIntervalId = null;
let isNavigating = false; // Biến cờ để tránh việc chuyển trang bị gọi 2 lần liên tiếp

// Danh sách link không giới hạn. Bạn có thể thêm bao nhiêu tùy thích.
const FIXED_LINKS = [
    "https://9xcongit.com/youtube-premium/",
    "https://9xcongit.com/how-to-check-gmail-creation-date-using-google-takeout/",
    "https://9xcongit.com/what-is-browserstack/",
    "https://9xcongit.com/how-to-create-a-free-gmail-address-in-the-us/",
    "https://9xcongit.com/what-is-a-vpn-discover-safe-private-web-browsing/",
    "https://9xcongit.com/1-1-1-1/",
    "https://9xcongit.com/what-is-tiktok-how-to-make-money-from-tiktok/",
    "https://9xcongit.com/what-is-socks5/",
    "https://9xcongit.com/what-is-portable-software/",
    "https://9xcongit.com/what-is-docker/",
    "https://9xcongit.com/what-is-ssl/",
    "https://9xcongit.com/future/",
    "https://9xcongit.com/stock/",
    "https://9xcongit.com/1-usd/",
    "https://9xcongit.com/1-btc/",
    "https://9xcongit.com/how-to-open-a-successful-coffee-shop/",
    "https://9xcongit.com/steps-to-create-a-new-brand-and-start-selling/",
    "https://9xcongit.com/when-do-you-need-to-promote-your-business/",
    "https://9xcongit.com/increase-sales-with-repetitive-marketing-methods/",
    "https://9xcongit.com/the-crowd-effect-in-sales/",
    "https://9xcongit.com/increase-traffic-with-social-media-sharing-features/",
    "https://9xcongit.com/making-money-online-mmo-massive-online-opportunity/",
    "https://9xcongit.com/the-best-side-jobs-to-boost-your-income-from-home/",
    "https://9xcongit.com/stay-ahead-of-your-competitors-with-a-professional-seo-company/",
    "https://9xcongit.com/what-major-should-you-choose-to-create-million-view-content/",
    "https://9xcongit.com/how-to-try-nvidia-gpu-free/",
    "https://9xcongit.com/bitcoin/",
    "https://9xcongit.com/how-to-mine-dogecoin/",
    "https://9xcongit.com/how-to-create-free-46-vcpu-vps-with-root-access/",
    "https://9xcongit.com/how-to-get-a-free-vps-with-root-access-8vcpu/"
];

// Hàm xử lý việc chuyển sang link tiếp theo theo thứ tự
function goToNextPage() {
    if (isNavigating) return; // Nếu đang chuyển trang rồi thì bỏ qua
    isNavigating = true;

    stopScrolling();
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }

    // Lấy chỉ số link hiện tại từ bộ nhớ (mặc định là 0 nếu chưa có)
    chrome.storage.local.get(['currentLinkIndex'], (result) => {
        let currentIndex = result.currentLinkIndex || 0;

        // Đề phòng trường hợp bạn xóa bớt link trong code khiến index vượt quá mảng
        if (currentIndex >= FIXED_LINKS.length) {
            currentIndex = 0;
        }

        const nextUrl = FIXED_LINKS[currentIndex];
        console.log("Auto Browser: Sẽ chuyển hướng đến -> " + nextUrl);

        // Tính toán vị trí link TIẾP THEO (nếu đến cuối mảng thì quay lại 0)
        const nextIndex = (currentIndex + 1) % FIXED_LINKS.length;

        // Lưu vị trí tiếp theo vào storage và thực hiện chuyển trang
        chrome.storage.local.set({ currentLinkIndex: nextIndex }, () => {
            window.location.href = nextUrl;
        });
    });
}

function startScrolling() {
    const SCROLL_SPEED = 30;

    scrollIntervalId = setInterval(() => {
        // Kiểm tra xem đã cuộn đến cuối trang chưa (-5px để trừ hao các sai số trên một số màn hình)
        const isAtBottom = (window.innerHeight + Math.ceil(window.scrollY)) >= document.body.offsetHeight - 5;
        
        if (!isAtBottom) {
            window.scrollBy(0, 2); // Cuộn xuống 2 pixel
        } else {
            console.log("Auto Browser: Đã đến cuối trang, bỏ qua thời gian chờ và chuyển link mới!");
            goToNextPage(); // Chuyển trang NGAY LẬP TỨC
        }
    }, SCROLL_SPEED);
}

function stopScrolling() {
    if (scrollIntervalId) {
        clearInterval(scrollIntervalId);
        scrollIntervalId = null;
    }
}

function startAutoBrowse() {
    // 1. KIỂM TRA QUẢNG CÁO
    if (window.location.href.includes('google_vignette')) {
        console.log("Auto Browser: Bị kẹt ở trang quảng cáo, đang tự động chuyển về trang chủ...");
        window.location.href = 'https://9xcongit.com/';
        return; 
    }

    // Thời gian chờ ngẫu nhiên từ 30s (30,000 ms) đến 60s (60,000 ms)
    const MIN_TIME = 30000;
    const MAX_TIME = 60000;
    const waitTime = Math.floor(Math.random() * (MAX_TIME - MIN_TIME + 1)) + MIN_TIME; 

    console.log(`Auto Browser: Thời gian tối đa ở trang này là ${Math.round(waitTime/1000)} giây...`);

    // Bắt đầu cuộn trang
    startScrolling();

    // Hẹn giờ chuyển trang (chỉ hoạt động nếu trang quá dài, chưa cuộn kịp đến cuối)
    timerId = setTimeout(() => {
        console.log("Auto Browser: Đã hết thời gian lướt trang, tiến hành chuyển link...");
        goToNextPage();
    }, waitTime); 
}

function stopAutoBrowse() {
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }
    stopScrolling();
    isNavigating = false;
    console.log("Auto Browser: Đã dừng.");
}

// Khởi tạo trạng thái khi trang vừa load xong
chrome.storage.local.get(['autoBrowseActive'], (result) => {
    if (result.autoBrowseActive) {
        startAutoBrowse();
    }
});

// Lắng nghe thay đổi khi bạn bật/tắt từ Popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (changes.autoBrowseActive) {
        if (changes.autoBrowseActive.newValue) {
            startAutoBrowse();
        } else {
            stopAutoBrowse();
        }
    }
});