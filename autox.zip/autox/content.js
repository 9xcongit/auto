let timerId = null;
let scrollIntervalId = null;
let adCheckIntervalId = null; // Biến lưu ID của vòng lặp quét quảng cáo
let isNavigating = false; // Biến cờ để tránh việc chuyển trang bị gọi 2 lần liên tiếp
let isViewingAd = false; // Cờ kiểm tra xem có đang dừng lại để xem quảng cáo không

// Danh sách link không giới hạn. Bạn có thể thêm bao nhiêu tùy thích.
const FIXED_LINKS = [
    "https://9xcongit.com/how-to-get-a-free-vps-with-root-access-8vcpu/",
	"https://9xcongit.com/free-vps-24-7-uptime-tutorial/"
	"https://9xcongit.com/how-to-get-a-free-vps-with-root-access-8vcpu/",
	"https://9xcongit.com/how-to-get-a-free-vps-with-quiklab/",
	"https://9xcongit.com/how-to-create-free-46-vcpu-vps-with-root-access/",
	"https://9xcongit.com/how-to-try-nvidia-gpu-free/",
    "https://9xcongit.com/how-to-check-gmail-creation-date-using-google-takeout/",
    "https://9xcongit.com/free-vps-keep-dying-how-to-maintain-100-uptime-until-the-end-of-2026/",
    "https://9xcongit.com/how-to-create-a-free-gmail-address-in-the-us/",
    "https://9xcongit.com/free-cloudsigma-trial-7-day-instant-demo/",
    "https://9xcongit.com/create-free-vps-play-with-docker/",
    "https://9xcongit.com/what-is-tiktok-how-to-make-money-from-tiktok/",
    "https://9xcongit.com/what-is-socks5/",
    "https://9xcongit.com/how-to-get-free-vps-no-credit-card/",
    "https://9xcongit.com/what-is-docker/",
    "https://9xcongit.com/what-is-ssl/",
    "https://9xcongit.com/future/",
    "https://9xcongit.com/stock/",
    "https://9xcongit.com/1-usd/",
    "https://9xcongit.com/1-btc/",
    "https://9xcongit.com/how-to-open-a-successful-coffee-shop/",
    "https://9xcongit.com/steps-to-create-a-new-brand-and-start-selling/",
    "https://9xcongit.com/when-do-you-need-to-promote-your-business/",
    "https://9xcongit.com/increase-sales-with-repetitive-marketing-methods/",
    "https://9xcongit.com/the-crowd-effect-in-sales/",
    "https://9xcongit.com/increase-traffic-with-social-media-sharing-features/",
    "https://9xcongit.com/making-money-online-mmo-massive-online-opportunity/",
    "https://9xcongit.com/the-best-side-jobs-to-boost-your-income-from-home/",
    "https://9xcongit.com/stay-ahead-of-your-competitors-with-a-professional-seo-company/",
    "https://9xcongit.com/what-major-should-you-choose-to-create-million-view-content/",
    "https://9xcongit.com/bitcoin/"
];

// Hàm xử lý việc chuyển sang link tiếp theo theo thứ tự
function goToNextPage() {
    // Nếu đang trong thời gian xem quảng cáo (10 giây) mà lại hết giờ lướt web
    // Chúng ta sẽ "gia hạn" thêm 10 giây nữa rồi mới chuyển trang, để xem nốt quảng cáo.
    if (isViewingAd) {
        timerId = setTimeout(goToNextPage, 10000);
        return;
    }

    if (isNavigating) return;
    isNavigating = true;

    stopScrolling();
    stopAdScanner(); // Dừng quét quảng cáo khi chuẩn bị chuyển trang
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }

    chrome.storage.local.get(['currentLinkIndex'], (result) => {
        let currentIndex = result.currentLinkIndex || 0;

        if (currentIndex >= FIXED_LINKS.length) {
            currentIndex = 0;
        }

        const nextUrl = FIXED_LINKS[currentIndex];
        console.log("Auto Browser: Sẽ chuyển hướng đến -> " + nextUrl);

        const nextIndex = (currentIndex + 1) % FIXED_LINKS.length;

        chrome.storage.local.set({ currentLinkIndex: nextIndex }, () => {
            window.location.href = nextUrl;
        });
    });
}

// ----------------- TÌM VÀ CLICK VĂN BẢN Ý ĐỊNH (AD INTENTS) -----------------
function scanAndClickHiddenAds() {
    // Nếu đang trong quá trình dừng 10s để xem quảng cáo, thì không quét thêm
    if (isViewingAd) return; 

    // Các class và thuộc tính nhận diện đặc trưng mà Google AdSense hay dùng cho Ad Intents
    const intentSelectors = [
        'a[class*="google-anno"]', 
        'a[class*="intent"]', 
        '[class*="google-intent"]',
        'a[data-ad-intent]',
        'a[data-google-query-id]', 
        'span[class*="google-anno"]'
    ].join(', ');

    // Tìm các phần tử văn bản ý định trên trang
    const intentElements = document.querySelectorAll(intentSelectors);
    
    for (let i = 0; i < intentElements.length; i++) {
        const el = intentElements[i];

        // Nếu văn bản này ĐÃ TỪNG được click trước đó trên cùng trang này thì bỏ qua
        if (el.dataset.autoClicked === "true") continue;
        
        // Tuyệt đối bỏ qua nếu thẻ này nằm trong banner quảng cáo (<ins> hoặc <iframe>)
        const isBannerAd = el.closest('ins.adsbygoogle') || el.closest('iframe');

        if (!isBannerAd) {
            console.log("Auto Browser: Phát hiện Văn bản Ý định Google ->", el.innerText || "Văn bản ẩn");
            
            try {
                // Nhấn vào văn bản
                el.click(); 
                el.dataset.autoClicked = "true"; // Đánh dấu đã click để sau lướt qua không click lại
                isViewingAd = true; // Bật cờ thông báo đang xem QC
                
                console.log("Auto Browser: Đã click! Tạm dừng cuộn trang 10 giây để xem quảng cáo...");
                stopScrolling(); // Dừng cuộn trang
                
                // Hẹn đúng 10 giây sau sẽ tắt popup và lướt tiếp
                setTimeout(() => {
                    closeAdAndResume();
                }, 10000);

                break; // Xử lý 1 quảng cáo xong thì dừng vòng lặp (đợi cái tiếp theo)
            } catch (error) {
                console.error("Auto Browser: Lỗi không click được văn bản", error);
            }
        }
    }
}

// Hàm tắt popup quảng cáo và tiếp tục lướt web
function closeAdAndResume() {
    console.log("Auto Browser: Đã xem xong 10 giây. Đóng popup quảng cáo và lướt tiếp...");
    
    // 1. Gửi sự kiện phím "ESC" với thuộc tính đầy đủ hơn
    const escEvent = new KeyboardEvent('keydown', {
        key: 'Escape', code: 'Escape', keyCode: 27, which: 27, 
        bubbles: true, cancelable: true, composed: true
    });
    document.dispatchEvent(escEvent);
    document.body.dispatchEvent(escEvent);

    // 2. Cố gắng tìm và click các nút "Đóng" (mở rộng bộ tìm kiếm)
    const closeSelectors = [
        '[aria-label*="Close"]', '[aria-label*="Đóng"]', '[aria-label*="Đóng quảng cáo"]',
        '.close-button', '.btn-close', '#dismiss-button', '[id*="dismiss"]'
    ].join(', ');
    
    const closeButtons = document.querySelectorAll(closeSelectors);
    closeButtons.forEach(btn => {
        try { btn.click(); } catch (e) {}
    });

    // 3. BIỆN PHÁP MẠNH: Tìm các Overlay toàn màn hình (Lớp phủ quảng cáo của Google) và ẩn đi
    try {
        const allOverlays = document.querySelectorAll('ins.adsbygoogle, iframe, div');
        allOverlays.forEach(el => {
            const style = window.getComputedStyle(el);
            // Kích hoạt nếu nó là dạng fixed/absolute và có z-index cực cao (trên cùng)
            if ((style.position === 'fixed' || style.position === 'absolute') && parseInt(style.zIndex, 10) > 1000) {
                const rect = el.getBoundingClientRect();
                // Xác nhận nó chiếm phần lớn màn hình
                if (rect.width > window.innerWidth * 0.4 && rect.height > window.innerHeight * 0.4) {
                    console.log("Auto Browser: Đã dùng biện pháp mạnh - Ẩn lớp phủ quảng cáo.");
                    el.style.display = 'none';
                    el.style.opacity = '0';
                    el.style.pointerEvents = 'none';
                }
            }
        });

        // Mở khóa lại thanh cuộn (Đôi khi Google khóa cuộn trang bằng overflow: hidden)
        document.body.style.overflow = 'auto';
        document.documentElement.style.overflow = 'auto';
    } catch (err) {
        console.error("Auto Browser: Lỗi trong quá trình ẩn Overlay", err);
    }

    // Chờ 1 giây cho hiệu ứng tắt popup hoàn tất rồi mới cuộn tiếp
    setTimeout(() => {
        isViewingAd = false;
        // Kiểm tra chắc chắn là chưa tới lúc chuyển trang thì mới cuộn tiếp
        if (!isNavigating) {
            startScrolling();
        }
    }, 1000);
}

function startAdScanner() {
    // Cứ mỗi 3 giây sẽ quét trang 1 lần xem Google đã render văn bản ý định ra chưa
    adCheckIntervalId = setInterval(() => {
        scanAndClickHiddenAds();
    }, 3000);
}

function stopAdScanner() {
    if (adCheckIntervalId) {
        clearInterval(adCheckIntervalId);
        adCheckIntervalId = null;
    }
}
// ----------------------------------------------------------------------

function startScrolling() {
    const SCROLL_SPEED = 30;

    // Đảm bảo không tạo ra nhiều tiến trình cuộn cùng lúc
    stopScrolling();

    scrollIntervalId = setInterval(() => {
        const isAtBottom = (window.innerHeight + Math.ceil(window.scrollY)) >= document.body.offsetHeight - 5;
        
        if (!isAtBottom) {
            window.scrollBy(0, 2); 
        } else {
            console.log("Auto Browser: Đã đến cuối trang, bỏ qua thời gian chờ và chuyển link mới!");
            goToNextPage(); 
        }
    }, SCROLL_SPEED);
}

function stopScrolling() {
    if (scrollIntervalId) {
        clearInterval(scrollIntervalId);
        scrollIntervalId = null;
    }
}

function startAutoBrowse() {
    // 1. KIỂM TRA QUẢNG CÁO TOÀN MÀN HÌNH (VIGNETTE)
    if (window.location.href.includes('google_vignette')) {
        console.log("Auto Browser: Bị kẹt ở trang quảng cáo, đang tự động chuyển về trang chủ...");
        window.location.href = 'https://9xcongit.com/';
        return; 
    }

    // Thời gian chờ ngẫu nhiên từ 30s đến 60s
    const MIN_TIME = 30000;
    const MAX_TIME = 60000;
    const waitTime = Math.floor(Math.random() * (MAX_TIME - MIN_TIME + 1)) + MIN_TIME; 

    console.log(`Auto Browser: Thời gian tối đa ở trang này là ${Math.round(waitTime/1000)} giây...`);

    // Bắt đầu các tiến trình
    startScrolling();
    startAdScanner(); // Bật bộ quét văn bản ý định

    // Hẹn giờ chuyển trang
    timerId = setTimeout(() => {
        console.log("Auto Browser: Đã hết thời gian lướt trang, tiến hành chuyển link...");
        goToNextPage();
    }, waitTime); 
}

function stopAutoBrowse() {
    if (timerId) {
        clearTimeout(timerId);
        timerId = null;
    }
    stopScrolling();
    stopAdScanner(); // Tắt bộ quét
    isNavigating = false;
    isViewingAd = false;
    console.log("Auto Browser: Đã dừng.");
}

// Khởi tạo trạng thái khi trang vừa load xong
chrome.storage.local.get(['autoBrowseActive'], (result) => {
    if (result.autoBrowseActive) {
        startAutoBrowse();
    }
});

// Lắng nghe thay đổi khi bạn bật/tắt từ Popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (changes.autoBrowseActive) {
        if (changes.autoBrowseActive.newValue) {
            startAutoBrowse();
        } else {
            stopAutoBrowse();
        }
    }
});