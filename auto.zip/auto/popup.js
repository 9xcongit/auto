document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const statusDiv = document.getElementById('status');

  // Load current state from local storage
  chrome.storage.local.get(['autoBrowseActive'], (result) => {
    updateUI(result.autoBrowseActive);
  });

  // Handle "Start" button click
  startBtn.addEventListener('click', () => {
    chrome.storage.local.set({ autoBrowseActive: true }, () => {
      updateUI(true);
      
      // Check if currently on 9xcongit.com, if not open it
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if(tabs[0].url && tabs[0].url.includes("9xcongit.com")) {
              chrome.tabs.reload(tabs[0].id); // Reload to activate script
          } else {
              chrome.tabs.create({url: "https://9xcongit.com/"});
          }
      });
    });
  });

  // Handle "Stop" button click
  stopBtn.addEventListener('click', () => {
    chrome.storage.local.set({ autoBrowseActive: false }, () => {
      updateUI(false);
    });
  });

  // Update User Interface
  function updateUI(isActive) {
    if (isActive) {
      statusDiv.innerText = "Status: ACTIVE";
      statusDiv.style.color = "#4CAF50";
    } else {
      statusDiv.innerText = "Status: OFF";
      statusDiv.style.color = "#f44336";
    }
  }
});